"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

// Casos de F2L com descrições e algoritmos
const casosF2L = [
  {
    id: 1,
    nome: "Caso Básico 1",
    descricao: "Canto e aresta já formam um par, mas estão na camada superior",
    algoritmo: "U (R U' R')",
    dica: "Posicione o par sobre o slot correto e insira com R U' R'",
  },
  {
    id: 2,
    nome: "Caso Básico 2",
    descricao: "Canto na camada superior, aresta no slot errado",
    algoritmo: "U' (R U R') U' (R U R')",
    dica: "Primeiro remova a aresta do slot errado, depois insira o par",
  },
  {
    id: 3,
    nome: "Caso Básico 3",
    descricao: "Canto e aresta separados na camada superior",
    algoritmo: "U (R U R' U') (R U R')",
    dica: "Alinhe o canto e a aresta, depois insira com a sequência",
  },
  {
    id: 4,
    nome: "Caso Avançado 1",
    descricao: "Canto no slot, aresta na camada superior",
    algoritmo: "(R U' R') U (R U' R') U' (R U R')",
    dica: "Remova o canto, posicione a aresta e reinsira o par",
  },
  {
    id: 5,
    nome: "Caso Avançado 2",
    descricao: "Canto e aresta no slot, mas orientados incorretamente",
    algoritmo: "(R U R' U') (R U R' U') (R U R')",
    dica: "Remova o par, reoriente e reinsira corretamente",
  },
]

export default function F2LTrainer() {
  const [casoAtual, setCasoAtual] = useState(0)
  const [mostrarSolucao, setMostrarSolucao] = useState(false)

  const proximoCaso = () => {
    setCasoAtual((prev) => (prev + 1) % casosF2L.length)
    setMostrarSolucao(false)
  }

  const casoAnterior = () => {
    setCasoAtual((prev) => (prev - 1 + casosF2L.length) % casosF2L.length)
    setMostrarSolucao(false)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4">
          <h3 className="text-lg font-bold mb-2">{casosF2L[casoAtual].nome}</h3>
          <p className="text-sm mb-4">{casosF2L[casoAtual].descricao}</p>

          <div className="flex justify-center mb-4">
            {/* Placeholder para imagem do caso F2L */}
            <div className="bg-gray-200 w-48 h-48 flex items-center justify-center rounded-md">
              <p className="text-sm text-gray-500">Imagem do caso F2L #{casosF2L[casoAtual].id}</p>
            </div>
          </div>

          <div className="flex justify-between mb-4">
            <Button variant="outline" onClick={casoAnterior}>
              Anterior
            </Button>
            <Button variant="outline" onClick={proximoCaso}>
              Próximo
            </Button>
          </div>

          <Button className="w-full mb-2" onClick={() => setMostrarSolucao(!mostrarSolucao)}>
            {mostrarSolucao ? "Esconder Solução" : "Mostrar Solução"}
          </Button>

          {mostrarSolucao && (
            <div className="mt-4 p-3 bg-gray-100 rounded-md">
              <p className="font-medium">
                Algoritmo: <span className="font-mono">{casosF2L[casoAtual].algoritmo}</span>
              </p>
              <p className="text-sm mt-2">💡 Dica: {casosF2L[casoAtual].dica}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="text-sm text-center text-gray-500">Pratique estes casos para melhorar sua velocidade no F2L!</div>
    </div>
  )
}
