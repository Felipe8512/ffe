"use client"

import { useRef, useState, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera } from "@react-three/drei"
import { Button } from "@/components/ui/button"

// Cores padrão do cubo de Rubik
const CORES = {
  branco: "#FFFFFF", // U - cima
  amarelo: "#FFDA00", // D - baixo - amarelo mais vibrante
  verde: "#009E60", // F - frente - verde padrão do Rubik
  azul: "#0051BA", // B - trás - azul padrão do Rubik
  vermelho: "#C41E3A", // R - direita - vermelho padrão do Rubik
  laranja: "#FF5800", // L - esquerda - laranja padrão do Rubik
  preto: "#1A1A1A", // cor da borda/estrutura
}

// Componente para uma peça do cubo
function CubePiece({ position, colors }) {
  const meshRef = useRef()

  return (
    <mesh ref={meshRef} position={position}>
      <boxGeometry args={[0.95, 0.95, 0.95]} />
      {[...Array(6)].map((_, index) => (
        <meshStandardMaterial
          key={index}
          attach={`material-${index}`}
          color={colors[index] || CORES.preto}
          roughness={0.1}
          metalness={0.1}
          emissive={colors[index] || CORES.preto}
          emissiveIntensity={0.05}
        />
      ))}
    </mesh>
  )
}

// Componente principal do cubo
function CubeModel({ autoRotate }) {
  const groupRef = useRef()

  // Gera um cubo resolvido (3x3x3)
  const cuboPecas = []

  for (let x = -1; x <= 1; x++) {
    for (let y = -1; y <= 1; y++) {
      for (let z = -1; z <= 1; z++) {
        // Pular o centro do cubo
        if (x === 0 && y === 0 && z === 0) continue

        // Determinar as cores de cada face
        const colors = [
          z === 1 ? CORES.azul : undefined, // Back
          z === -1 ? CORES.verde : undefined, // Front
          y === 1 ? CORES.branco : undefined, // Up
          y === -1 ? CORES.amarelo : undefined, // Down
          x === 1 ? CORES.vermelho : undefined, // Right
          x === -1 ? CORES.laranja : undefined, // Left
        ]

        cuboPecas.push({ position: [x, y, z], colors })
      }
    }
  }

  useFrame((state, delta) => {
    if (autoRotate && groupRef.current) {
      groupRef.current.rotation.y += delta * 0.5
    }
  })

  return (
    <group ref={groupRef}>
      {cuboPecas.map((peca, index) => (
        <CubePiece key={index} position={peca.position} colors={peca.colors} />
      ))}
    </group>
  )
}

export default function Cubo3D() {
  const [autoRotate, setAutoRotate] = useState(true)
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratação com SSR
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="w-full h-[300px] bg-gray-100 flex items-center justify-center rounded-md">
        <p>Carregando visualizador 3D...</p>
      </div>
    )
  }

  return (
    <div className="w-full h-[300px] relative bg-gray-50 rounded-md overflow-hidden">
      <Canvas shadows dpr={[1, 2]}>
        <color attach="background" args={["#f8f8f8"]} />
        <PerspectiveCamera makeDefault position={[3, 3, 5]} fov={45} />
        <ambientLight intensity={0.7} />
        <pointLight position={[10, 10, 10]} intensity={1} castShadow />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />
        <CubeModel autoRotate={autoRotate} />
        <OrbitControls
          enableZoom={true}
          enablePan={false}
          minDistance={4}
          maxDistance={10}
          onChange={() => setAutoRotate(false)}
        />
      </Canvas>
      <div className="absolute bottom-2 right-2">
        <Button
          size="sm"
          onClick={() => setAutoRotate(!autoRotate)}
          variant={autoRotate ? "default" : "outline"}
          className="text-xs"
        >
          {autoRotate ? "Parar Rotação" : "Auto-Rotação"}
        </Button>
      </div>
    </div>
  )
}
