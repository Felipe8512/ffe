"use client"

import { useRef, useState, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Cores padrão do cubo de Rubik
const CORES = {
  branco: "#FFFFFF", // U - cima
  amarelo: "#FFDA00", // D - baixo - amarelo mais vibrante
  verde: "#009E60", // F - frente - verde padrão do Rubik
  azul: "#0051BA", // B - trás - azul padrão do Rubik
  vermelho: "#C41E3A", // R - direita - vermelho padrão do Rubik
  laranja: "#FF5800", // L - esquerda - laranja padrão do Rubik
  preto: "#1A1A1A", // cor da borda/estrutura
}

// Mapeamento de notação para transformações
const MOVIMENTOS = {
  R: { eixo: "x", camada: 1, sentido: 1 },
  "R'": { eixo: "x", camada: 1, sentido: -1 },
  L: { eixo: "x", camada: -1, sentido: -1 },
  "L'": { eixo: "x", camada: -1, sentido: 1 },
  U: { eixo: "y", camada: 1, sentido: 1 },
  "U'": { eixo: "y", camada: 1, sentido: -1 },
  D: { eixo: "y", camada: -1, sentido: -1 },
  "D'": { eixo: "y", camada: -1, sentido: 1 },
  F: { eixo: "z", camada: -1, sentido: 1 },
  "F'": { eixo: "z", camada: -1, sentido: -1 },
  B: { eixo: "z", camada: 1, sentido: -1 },
  "B'": { eixo: "z", camada: 1, sentido: 1 },
}

// Componente para uma peça do cubo
function CubePiece({ position, colors, isAnimating }) {
  const meshRef = useRef()

  return (
    <mesh ref={meshRef} position={position} castShadow receiveShadow>
      <boxGeometry args={[0.95, 0.95, 0.95]} />
      {[...Array(6)].map((_, index) => (
        <meshStandardMaterial
          key={index}
          attach={`material-${index}`}
          color={colors[index] || CORES.preto}
          roughness={0.1}
          metalness={0.1}
          emissive={colors[index] || CORES.preto}
          emissiveIntensity={0.05}
        />
      ))}
    </mesh>
  )
}

// Componente para animação de rotação
function RotatingGroup({ children, isAnimating, eixo, sentido, onAnimationComplete }) {
  const groupRef = useRef()
  const [rotation, setRotation] = useState(0)
  const targetRotation = (Math.PI / 2) * sentido

  useFrame((state, delta) => {
    if (isAnimating && groupRef.current) {
      const step = delta * 5 // Velocidade da animação
      const newRotation = rotation + step * Math.sign(targetRotation - rotation)

      if (Math.abs(newRotation) >= Math.abs(targetRotation)) {
        setRotation(targetRotation)
        onAnimationComplete()
      } else {
        setRotation(newRotation)
      }

      if (eixo === "x") groupRef.current.rotation.x = rotation
      else if (eixo === "y") groupRef.current.rotation.y = rotation
      else if (eixo === "z") groupRef.current.rotation.z = rotation
    }
  })

  return <group ref={groupRef}>{children}</group>
}

export default function CuboInterativo() {
  const [estado, setEstado] = useState([])
  const [movimento, setMovimento] = useState("R")
  const [animando, setAnimando] = useState(false)
  const [pecasAnimando, setPecasAnimando] = useState([])
  const [mounted, setMounted] = useState(false)

  // Inicializar o cubo
  useEffect(() => {
    // Inicializa um cubo resolvido
    const cubo = []
    for (let x = -1; x <= 1; x++) {
      for (let y = -1; y <= 1; y++) {
        for (let z = -1; z <= 1; z++) {
          if (x === 0 && y === 0 && z === 0) continue

          const colors = [
            z === 1 ? CORES.azul : undefined, // Back
            z === -1 ? CORES.verde : undefined, // Front
            y === 1 ? CORES.branco : undefined, // Up
            y === -1 ? CORES.amarelo : undefined, // Down
            x === 1 ? CORES.vermelho : undefined, // Right
            x === -1 ? CORES.laranja : undefined, // Left
          ]

          cubo.push({
            position: [x, y, z],
            colors,
            id: `${x},${y},${z}`,
            key: Math.random().toString(36).substr(2, 9),
          })
        }
      }
    }
    setEstado(cubo)
    setMounted(true)
  }, [])

  const aplicarMovimento = (mov) => {
    if (animando || !mounted) return

    const { eixo, camada, sentido } = MOVIMENTOS[mov]

    // Encontrar peças afetadas pelo movimento
    const pecasAfetadas = estado.filter((peca) => {
      const [x, y, z] = peca.position
      if (eixo === "x" && Math.round(x) === camada) return true
      if (eixo === "y" && Math.round(y) === camada) return true
      if (eixo === "z" && Math.round(z) === camada) return true
      return false
    })

    setAnimando(true)
    setPecasAnimando(pecasAfetadas.map((p) => p.id))

    // Atualizar posições após o movimento
    setTimeout(() => {
      const novoEstado = [...estado]

      pecasAfetadas.forEach((peca) => {
        const idx = novoEstado.findIndex((p) => p.id === peca.id)
        const [x, y, z] = peca.position

        let novaPos, novasCores

        if (eixo === "x") {
          // Rotação em torno do eixo X
          novaPos = [x, z * -sentido, y * sentido]
          novasCores = [peca.colors[4], peca.colors[5], peca.colors[0], peca.colors[1], peca.colors[2], peca.colors[3]]
        } else if (eixo === "y") {
          // Rotação em torno do eixo Y
          novaPos = [z * sentido, y, x * -sentido]
          novasCores = [peca.colors[2], peca.colors[3], peca.colors[4], peca.colors[5], peca.colors[1], peca.colors[0]]
        } else {
          // Rotação em torno do eixo Z
          novaPos = [y * -sentido, x * sentido, z]
          novasCores = [peca.colors[0], peca.colors[1], peca.colors[5], peca.colors[4], peca.colors[3], peca.colors[2]]
        }

        novoEstado[idx] = {
          ...peca,
          position: novaPos,
          colors: novasCores,
          id: `${novaPos[0]},${novaPos[1]},${novaPos[2]}`,
          key: peca.key,
        }
      })

      setEstado(novoEstado)
      setPecasAnimando([])
      setAnimando(false)
    }, 500) // Tempo da animação
  }

  if (!mounted) {
    return (
      <div className="w-full h-[400px] bg-gray-100 flex items-center justify-center rounded-md">
        <p>Carregando cubo interativo...</p>
      </div>
    )
  }

  return (
    <div className="w-full h-[400px] relative bg-gray-50 rounded-md overflow-hidden">
      <Canvas shadows dpr={[1, 2]}>
        <color attach="background" args={["#f8f8f8"]} />
        <PerspectiveCamera makeDefault position={[3, 3, 5]} fov={45} />
        <ambientLight intensity={0.7} />
        <pointLight position={[10, 10, 10]} intensity={1} castShadow />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />
        <group>
          {estado.map((peca) => {
            const isAnimating = pecasAnimando.includes(peca.id)
            return <CubePiece key={peca.key} position={peca.position} colors={peca.colors} isAnimating={isAnimating} />
          })}
        </group>
        <OrbitControls enableZoom={true} enablePan={false} minDistance={4} maxDistance={10} />
      </Canvas>

      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
        <Select value={movimento} onValueChange={setMovimento} disabled={animando}>
          <SelectTrigger className="w-[80px]">
            <SelectValue placeholder="Movimento" />
          </SelectTrigger>
          <SelectContent>
            {Object.keys(MOVIMENTOS).map((mov) => (
              <SelectItem key={mov} value={mov}>
                {mov}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button onClick={() => aplicarMovimento(movimento)} disabled={animando}>
          {animando ? "Animando..." : "Aplicar"}
        </Button>

        <Button variant="outline" onClick={() => window.location.reload()}>
          Resetar
        </Button>
      </div>
    </div>
  )
}
