"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import dynamic from "next/dynamic"

const Cubo3D = dynamic(() => import("@/components/Cubo3D"), { ssr: false })
const CuboInterativo = dynamic(() => import("@/components/CuboInterativo"), { ssr: false })
const F2LTrainer = dynamic(() => import("@/components/F2LTrainer"), { ssr: false })

const conhecimento = {
  cruz: "A cruz é o primeiro passo no método camada por camada. Comece alinhando as arestas da cor branca com os centros correspondentes.",
  cfop: "O método mais usado para speedcubing é o CFOP (Cross, F2L, OLL, PLL).",
  f2l: "F2L significa 'First Two Layers' e resolve cantos e arestas juntos.",
  notacao: "Notação é a forma padrão de descrever movimentos: R, U, L', F2 etc.",
  recorde: "O recorde mundial de 3x3 é de 3.13s por Max Park (2023).",
  oll: "OLL (Orientation of Last Layer) orienta todas as peças da última camada para que a face superior tenha a mesma cor.",
  pll: "PLL (Permutation of Last Layer) permuta as peças da última camada para resolver o cubo completamente.",
  beginner:
    "O método para iniciantes geralmente resolve o cubo em camadas: primeira cruz, primeira camada, segunda camada e última camada.",
  roux: "O método Roux é uma alternativa ao CFOP que usa blocos e menos movimentos.",
  zbll: "ZBLL é um conjunto de 493 algoritmos que resolvem a última camada em um único passo.",
}

const quiz = [
  {
    pergunta: "Qual a primeira etapa do método CFOP?",
    opcoes: ["OLL", "Cross", "F2L", "PLL"],
    correta: "Cross",
  },
  {
    pergunta: "O que significa a sigla F2L?",
    opcoes: ["Final 2 Layers", "First 2 Lines", "First 2 Layers", "Fast Layer Logic"],
    correta: "First 2 Layers",
  },
  {
    pergunta: "Quantos algoritmos existem no conjunto completo de OLL?",
    opcoes: ["21", "42", "57", "78"],
    correta: "57",
  },
  {
    pergunta: "Qual movimento gira a face direita no sentido horário?",
    opcoes: ["R", "R'", "L", "L'"],
    correta: "R",
  },
  {
    pergunta: "Qual método usa blocos 1x2x3 como parte da solução?",
    opcoes: ["CFOP", "Roux", "ZZ", "Petrus"],
    correta: "Roux",
  },
]

function responderPergunta(pergunta) {
  pergunta = pergunta.toLowerCase()
  for (const chave in conhecimento) {
    if (pergunta.includes(chave)) {
      return conhecimento[chave]
    }
  }
  return "Desculpe, ainda não sei responder isso 😅"
}

export default function Home() {
  const [pergunta, setPergunta] = useState("")
  const [resposta, setResposta] = useState("")
  const [estadoCubo, setEstadoCubo] = useState("")
  const [solucao, setSolucao] = useState("")
  const [perguntaQuiz, setPerguntaQuiz] = useState(0)
  const [respostaQuiz, setRespostaQuiz] = useState(null)

  const resolverCubo = async () => {
    try {
      const res = await fetch("https://cubo-magico-api.vercel.app/api/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ estado: estadoCubo }),
      })
      const data = await res.json()
      setSolucao(data.solucao || "Erro ao resolver cubo.")
    } catch (err) {
      setSolucao("Erro ao se conectar com o servidor.")
    }
  }

  const responderQuiz = (resposta) => {
    setRespostaQuiz(resposta === quiz[perguntaQuiz].correta)
    setTimeout(() => {
      setRespostaQuiz(null)
      setPerguntaQuiz((prev) => (prev + 1) % quiz.length)
    }, 1500)
  }

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-center">🤖 Cubo Mágico AI</h1>

      <Tabs defaultValue="chat">
        <TabsList className="grid grid-cols-5 gap-1 mb-4">
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="resolver">Resolver</TabsTrigger>
          <TabsTrigger value="f2l">F2L</TabsTrigger>
          <TabsTrigger value="quiz">Quiz</TabsTrigger>
          <TabsTrigger value="cubo3d">Cubo 3D</TabsTrigger>
        </TabsList>

        <TabsContent value="chat">
          <Card>
            <CardContent className="p-4 space-y-2">
              <h2 className="font-semibold">Fazer uma pergunta</h2>
              <Input
                placeholder="Ex: como resolver a cruz?"
                value={pergunta}
                onChange={(e) => setPergunta(e.target.value)}
              />
              <Button onClick={() => setResposta(responderPergunta(pergunta))}>Responder</Button>
              {resposta && <p className="mt-2">📚 {resposta}</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resolver">
          <Card>
            <CardContent className="p-4 space-y-2">
              <h2 className="font-semibold">Resolver cubo mágico</h2>
              <Input
                placeholder="Cole o estado do cubo (54 letras: UUU...RRR...)"
                value={estadoCubo}
                onChange={(e) => setEstadoCubo(e.target.value)}
              />
              <Button onClick={resolverCubo}>Resolver</Button>
              {solucao && <p className="mt-2">🧩 {solucao}</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="f2l">
          <F2LTrainer />
        </TabsContent>

        <TabsContent value="quiz">
          <Card>
            <CardContent className="p-4 space-y-2">
              <h2 className="font-semibold">🧠 Quiz Cubo Mágico</h2>
              <p>{quiz[perguntaQuiz].pergunta}</p>
              <div className="grid grid-cols-2 gap-2">
                {quiz[perguntaQuiz].opcoes.map((opcao, idx) => (
                  <Button
                    key={idx}
                    variant={
                      respostaQuiz != null ? (opcao === quiz[perguntaQuiz].correta ? "default" : "outline") : "outline"
                    }
                    onClick={() => responderQuiz(opcao)}
                    disabled={respostaQuiz != null}
                  >
                    {opcao}
                  </Button>
                ))}
              </div>
              {respostaQuiz != null && <p className="mt-2">{respostaQuiz ? "✅ Correto!" : "❌ Errado!"}</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cubo3d">
          <Card>
            <CardContent className="p-4">
              <h2 className="font-semibold mb-2">🧊 Visualizador 3D</h2>
              <Cubo3D />
              <div className="mt-4">
                <h3 className="font-semibold mb-2">🎮 Cubo Interativo</h3>
                <CuboInterativo />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
